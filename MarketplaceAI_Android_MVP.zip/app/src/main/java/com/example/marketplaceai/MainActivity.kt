package com.example.marketplaceai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                MarketplaceScreen()
            }
        }
    }
}

@Composable
fun MarketplaceScreen(vm: MarketplaceViewModel = viewModel()) {
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> if (uris.isNotEmpty()) vm.generate(uris) }

    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var condition by remember { mutableStateOf("") }
    var tags by remember { mutableStateOf("") }

    LaunchedEffect(vm.listing) {
        vm.listing?.let {
            title = it.title; desc = it.description; price = it.price
            category = it.category; condition = it.condition; tags = it.tags.joinToString(", ")
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Marketplace AI", style = MaterialTheme.typography.headlineMedium) }
        item { Text("Photos → AI listing → your approval → Facebook Marketplace automation") }
        item {
            Button(onClick = { picker.launch(arrayOf("image/*")) }, enabled = !vm.busy) {
                Text(if (vm.busy) "Generating…" else "Choose item photos")
            }
        }
        if (vm.error != null) item { Text(vm.error!!, color = MaterialTheme.colorScheme.error) }
        item { OutlinedTextField(title, {title=it}, label={Text("Title")}, modifier=Modifier.fillMaxWidth()) }
        item { OutlinedTextField(desc, {desc=it}, label={Text("Description")}, modifier=Modifier.fillMaxWidth(), minLines=5) }
        item { OutlinedTextField(price, {price=it}, label={Text("Price (CAD)")}, modifier=Modifier.fillMaxWidth()) }
        item { OutlinedTextField(category, {category=it}, label={Text("Category")}, modifier=Modifier.fillMaxWidth()) }
        item { OutlinedTextField(condition, {condition=it}, label={Text("Condition")}, modifier=Modifier.fillMaxWidth()) }
        item { OutlinedTextField(tags, {tags=it}, label={Text("Tags / keywords")}, modifier=Modifier.fillMaxWidth()) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    vm.save(title, desc, price, category, condition, tags)
                }) { Text("Save draft") }
                Button(
                    onClick = {
                        vm.save(title, desc, price, category, condition, tags)
                        vm.approveAndAutomate()
                    },
                    enabled = title.isNotBlank() && !vm.posting
                ) { Text(if(vm.posting) "Opening Facebook…" else "Approve & Post") }
            }
        }
        item {
            OutlinedButton(onClick = {
                val ctx = vm.context
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }) { Text("Enable Facebook automation") }
        }
        item { Text("Safety: automation starts only after you press Approve & Post. Facebook must already be logged in on this phone. The app does not request your password.") }
    }
}
