package com.example.marketplaceai

import android.content.Context
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class OpenAIListingGenerator(private val context: Context) {
    private val client=OkHttpClient()
    suspend fun generate(uris:List<Uri>):Listing=withContext(Dispatchers.IO) {
        val key=context.getSharedPreferences("settings",0).getString("openai_key",null)
            ?: throw IllegalStateException("Add your OpenAI API key in the app settings before generating.")
        val content=JSONArray().apply {
            put(JSONObject().put("type","text").put("text",
                "Create a Facebook Marketplace listing from these photos. Return JSON with title, description, price, category, condition, tags. Price in CAD. Tags must be 10-20 short search phrases. Never invent facts not visible in the photos."))
            uris.take(10).forEach { uri ->
                val bytes=context.contentResolver.openInputStream(uri)!!.readBytes()
                val b64=Base64.encodeToString(bytes,Base64.NO_WRAP)
                put(JSONObject().put("type","image_url").put("image_url",JSONObject().put("url","data:image/jpeg;base64,$b64")))
            }
        }
        val body=JSONObject()
            .put("model","gpt-4.1-mini")
            .put("response_format",JSONObject().put("type","json_object"))
            .put("messages",JSONArray()
                .put(JSONObject().put("role","system").put("content","You are a careful Marketplace listing assistant."))
                .put(JSONObject().put("role","user").put("content",content)))
            .toString()
        val req=Request.Builder().url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization","Bearer $key")
            .post(body.toRequestBody("application/json".toMediaType())).build()
        val text=client.newCall(req).execute().use{r -> if(!r.isSuccessful) throw Exception("AI request failed: ${r.code}") else r.body!!.string()}
        val j=JSONObject(JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content"))
        Listing(j.getString("title"),j.getString("description"),j.getString("price"),j.getString("category"),j.getString("condition"),
            j.getJSONArray("tags").let { a -> (0 until a.length()).map{a.getString(it)} }, uris)
    }
}
