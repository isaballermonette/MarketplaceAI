package com.example.marketplaceai

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

data class Listing(
    val title:String, val description:String, val price:String,
    val category:String, val condition:String, val tags:List<String>,
    val photos:List<Uri> = emptyList()
)

class MarketplaceViewModel(app: Application): AndroidViewModel(app) {
    val context: Context = app
    var listing: Listing? = null
        private set
    var busy=false; private set
    var posting=false; private set
    var error:String?=null; private set

    fun generate(uris: List<Uri>) {
        viewModelScope.launch {
            busy=true; error=null
            try {
                listing = OpenAIListingGenerator(context).generate(uris)
            } catch(e: Exception) { error=e.message ?: "Could not generate listing." }
            busy=false
        }
    }

    fun save(t:String,d:String,p:String,c:String,co:String,tags:String) {
        listing = Listing(t,d,p,c,co,tags.split(",").map{it.trim()}.filter{it.isNotBlank()}, listing?.photos ?: emptyList())
    }

    fun approveAndAutomate() {
        val l=listing ?: return
        posting=true
        MarketplaceAccessibilityService.pending = l
        val i=Intent(context, MarketplaceAccessibilityService::class.java)
        context.startService(i)
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/marketplace/create/item")))
        posting=false
    }
}
