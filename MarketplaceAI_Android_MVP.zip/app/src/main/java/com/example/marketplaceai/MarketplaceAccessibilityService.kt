package com.example.marketplaceai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityNodeInfo

class MarketplaceAccessibilityService: AccessibilityService() {
    companion object { @Volatile var pending: Listing? = null }

    private val handler=Handler(Looper.getMainLooper())
    override fun onServiceConnected() { super.onServiceConnected() }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {
        val l=pending ?: return
        val root=rootInActiveWindow ?: return

        // Conservative automation: locate fields by visible text/content descriptions.
        // If Facebook changes its UI, stop rather than blindly typing into an unknown field.
        fillIfPresent(root, listOf("Title","title"), l.title)
        fillIfPresent(root, listOf("Price","price"), l.price)
        fillIfPresent(root, listOf("Description","description"), l.description)
        fillIfPresent(root, listOf("Category","category"), l.category)
        fillIfPresent(root, listOf("Condition","condition"), l.condition)

        // The final Facebook "Publish/Post" action is intentionally NOT clicked by the
        // accessibility service. The user must confirm the final public action in Facebook.
        // This preserves the requested approval gate and avoids accidental posting after UI changes.
    }

    private fun fillIfPresent(root:AccessibilityNodeInfo, labels:List<String>, value:String) {
        val nodes=labels.flatMap{root.findAccessibilityNodeInfosByText(it)}
        val node=nodes.firstOrNull { it.isEditable } ?: return
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,
            android.os.Bundle().apply{putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,value)})
    }
    override fun onInterrupt() {}
}
