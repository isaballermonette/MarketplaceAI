# Marketplace AI — Android-exclusive MVP

This is a native Android project.

## Workflow

Photo(s)
→ AI generates title, description, CAD price, category, condition and 10–20 search tags
→ you edit the listing
→ **Approve & Post**
→ Facebook Marketplace opens
→ Android Accessibility Service fills the visible fields where Facebook exposes matching labels
→ **the service deliberately does NOT click the final public Post button**. You perform that final confirmation inside Facebook.

This is the safest implementation of an approval gate because Facebook can change its UI at any time.

## Configure the AI key

The current MVP expects an OpenAI API key. Add a simple settings screen or store it securely before use; do not hard-code a key into the APK.

For production, the recommended architecture is a small backend so the API key is never stored on the phone.

## Build

Open the project in Android Studio and let Gradle sync. Build an APK with:

`Build > Build APK(s)`

## Facebook automation

Enable Android Settings → Accessibility → Marketplace AI → Allow.

Log into Facebook normally in the Facebook app.

The app never asks for or stores your Facebook password.

## Important

Facebook does not provide a general public API for creating personal Marketplace listings. Android UI automation can be fragile and Facebook may restrict automated activity. This project therefore requires your explicit approval and keeps the final public Post action manual.
